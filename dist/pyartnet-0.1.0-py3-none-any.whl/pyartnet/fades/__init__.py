from .fade_base import FadeBase
from .fade_linear import LinearFade
from .fade_quadratic import FadeQuadratic